import numpy as np
from operator_functions.pointer_func import pointer_vector
def LaplaceOpt_Aq(Q,Nx,Ny,dx,dy):

    iQ=pointer_vector(Nx, Ny)

    ## Initialize output 
    Y=np.nan*np.ones((len(Q),1))

    ## inner domain
    for i in range(1,Nx-1):
        for j in range(1,Ny-1):
            Y[iQ[i, j]] = (((Q[iQ[i-1, j]] - 2*Q[iQ[i, j]] + Q[iQ[i+1, j]] ) /(dx**2))+ ((Q[iQ[i, j-1]] - 2*Q[iQ[i, j]] + Q[iQ[i, j+1]] ) /(dy**2))) 

    ## Edges
    # left (Dirichlet)
    i = 0 ;
    for j in range(1,Ny-1):
            Y[iQ[i, j]] = (( (-2*Q[iQ[i, j]] + Q[iQ[i+1, j]] ) /(dx**2))+ ((Q[iQ[i, j-1]] - 2*Q[iQ[i, j]] + Q[iQ[i, j+1]] ) /(dy**2)))

    # top (Dirichlet)
    j = -1
    for i in range(1,Nx-1):
            Y[iQ[i, j]] = (((Q[iQ[i-1, j]] - 2*Q[iQ[i, j]] + Q[iQ[i+1, j]] ) /(dx**2))+ ((Q[iQ[i, j-1]] - 2*Q[iQ[i, j]] ) /(dy**2)))


    # Bottom (Neuman)
    j = 0
    for i in range(1,Nx-1):
            Y[iQ[i, j]] = (((Q[iQ[i-1, j]] - 2*Q[iQ[i, j]] + Q[iQ[i+1, j]] ) /(dx**2))+ ((-1*Q[iQ[i, j]] + Q[iQ[i, j+1]] ) /(dy**2)))


    # Right (Neuman)
    i=-1
    for j in range(1,Ny-1):
        Y[iQ[i, j]] = (( (Q[iQ[i-1, j]] - Q[iQ[i, j]] ) /(dx**2))+ ((Q[iQ[i, j-1]] - 2*Q[iQ[i, j]] + Q[iQ[i, j+1]] ) /(dy**2)))

        
    ## Corners
    # bottom left
    i = 0
    j = 0
    Y[iQ[i, j]] = (( (-2*Q[iQ[i, j]] + Q[iQ[i+1, j]] ) /(dx**2))+ ((-1*Q[iQ[i, j]] + Q[iQ[i, j+1]] ) /(dy**2))) 

    ## bottom right
    i=-1
    j=0

    Y[iQ[i, j]] = (((Q[iQ[i-1, j]] - Q[iQ[i, j]] ) /(dx**2))+ ((-1*Q[iQ[i, j]] + Q[iQ[i, j+1]] ) /(dy**2))) 

    ## top left
    j=-1
    i=0
    Y[iQ[i, j]] = (( (-2*Q[iQ[i, j]] + Q[iQ[i+1, j]] ) /(dx**2))+ ((Q[iQ[i, j-1]] - 2*Q[iQ[i, j]] ) /(dy**2))) 

    ## top right
    i=-1
    j=-1
    Y[iQ[i, j]] = (((Q[iQ[i-1, j]] - Q[iQ[i, j]] ) /(dx**2))+ (( Q[iQ[i, j-1]] - 2*Q[iQ[i, j]] )/(dy**2)))
    return Y

def uBC_Laplace1(Nx,Ny,dx,dy,BCB,BCL,BCT,BCR):
    iQ=pointer_vector(Nx, Ny)

    uBC  = np.zeros((Nx*Ny, 1)) ;

    ## Edges
    #left (Dirichlet)
    i = 0
    for j in range(1,Ny-1):
        uBC[iQ[i, j]] = BCL[j] / (dx**2)

    #bottom (Neuman)
    j = 0
    for i in range(1,Nx-1):
        uBC[iQ[i, j]] = -1*BCB[i] / (dy)

    # right(Neuman)
    i = -1
    for j in range(1,Ny-1):
        uBC[iQ[i, j]] = BCR[j] / (dx)

    # top(Dirichlet)
    j = -1
    for i in range(1,Nx-1):
        uBC[iQ[i, j]] = BCT[i] / (dy**2)

    ## Corners
    # bottom left (D-N)
    i = 0 ;
    j = 0 ;
    uBC[iQ[i, j]] = (BCL[i] /(dx**2)) - (BCB[j] /(dy))

    # bottom right (N-N)
    i = -1
    j = 0 
    uBC[iQ[i, j]] = (BCR[i] /(dx)) - (BCB[j] /(dy))

    # top left (D-D)
    i = 0
    j = -1 
    uBC[iQ[i, j]] = (BCL[i] /(dx**2)) + (BCT[j] /(dy**2))

    # top right (N-D)
    i=-1
    j=-1
    uBC[iQ[i, j]] = (BCR[i] /(dx)) + (BCT[j] /(dy**2))
    return uBC
def b_vector_creator(b,Nx,Ny,dx,dy,BCB,BCL,BCT,BCR):
    b_vector=np.zeros((Nx*Ny,1))
    iQ=pointer_vector(Nx, Ny)
    for i in range(0,Nx):
        for j in range(0,Ny):
            b_vector[iQ[i, j]]  = b[i,j]
    return (-1*b_vector-uBC_Laplace1(Nx,Ny,dx,dy,BCB,BCL,BCT,BCR))