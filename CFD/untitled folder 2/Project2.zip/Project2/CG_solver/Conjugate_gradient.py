import numpy as np
from operator_functions.pointer_func import pointer_vector


d_old=b_vector_creator(b,Nx,Ny,dx,dy,BCB,BCL,BCT,BCR)-LaplaceOpt_Aq(Q,Nx,Ny,dx,dy)
r_old=d_old


for i in range(100):
    intermediate_vec=LaplaceOpt_Aq(d_old,Nx,Ny,dx,dy)
    alpha_factor=((r_old.T)@r_old)/((d_old.T)@(intermediate_vec))

    Q=Q+(alpha_factor[0,0])*d_old
    r_new=r_old-(alpha_factor[0,0])*(intermediate_vec)

    beta=((r_new.T)@(r_new))/((r_old.T)@(r_old))
    d_new=r_new+(beta[0,0])*d_old

    d_old=d_new
    r_old=r_new
Solution_Matrix=np.zeros((Nx,Ny))
k=0
for i in range(Nx):
    for j in range(Ny):
        Solution_Matrix[i,j]=Q[k]
        k=k+1